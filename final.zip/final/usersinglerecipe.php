<!DOCTYPE html>
<?php include ('connection.php');
if(isset($_GET['id'])){
  $id=$_GET['id'];
}
?>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>User Single Recipe || Final</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="./assets/icon.jpg" type="image/x-icon" />
    <!-- normalize -->
    <link rel="stylesheet" href="./css/normalize.css" />
    <!-- font-awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"
    />
    <!-- main css -->
    <link rel="stylesheet" href="./css/main.css" />
    <!--Script--->
  </head>
  <body>
    <!-- nav  -->
    <nav class="navbar">
            <?php
                $sql="SELECT * FROM `addrecipe`WHERE`id`=$id";
                $res= mysqli_query($db, $sql);
                
                if (mysqli_num_rows($res)>0){ 
                    while ($product=mysqli_fetch_assoc($res)){ 
              ?>
      <div class="nav-center">
        <div class="nav-header">
          <a href="index.html" class="nav-logo">
            <img src="./assets/icon.jpg" alt="FOODiez" />
          </a>
          <button class="nav-btn btn">
            <i class="fas fa-align-justify"></i>
          </button>
        </div>
        <div class="nav-links">
          <a href="index.php" class="nav-link"> home </a>
          <a href="about.php" class="nav-link"> about </a>
          <a href="recipes.php" class="nav-link"> recipes </a>
          <a href="index.php?logout=true">LogOut</a>

          <div class="nav-link contact-link">
            <button type="submit" class="btn" onclick="openPopup()"> Order</button>
            <div class="popup" id="popup">
              <img src="./assets/recipes/<?php echo $product['img'];?>">
              <h2>Thank You</h2>
              <p>The given food will be reach to you after <p class="preptime"><?php echo $product['preptime'];?></p> + <p class="cooktime"><?php echo $product['cooktime'];?></p> + delivery time that is 30 min.</p>
              <a href="<?php echo"order.php?id=".$id;?>"><button type="button" onclick="closePopup()">order</button></a>
              <button type="button" onclick="closePopup()">cancel</button>
            </div>
          </div>
        </div>
      </div>
      <?php }}?>
    </nav>

    <script>
      let popup = document.getElementById("popup");

      function openPopup(){
        popup.classList.add("open-popup");
      }
      function closePopup(){
        popup.classList.remove("open-popup");
      }
    </script>
    <!-- end of nav -->
    <main class="page">
              <?php
                $sql="SELECT * FROM `addrecipe`WHERE`id`=$id";
                $res= mysqli_query($db, $sql);
                
                if (mysqli_num_rows($res)>0){ 
                    while ($product=mysqli_fetch_assoc($res)){ 
              ?>
      <div class="recipe-page">
        <section class="recipe-hero">
          <img
            src="./assets/recipes/<?php echo $product['img'];?>"
            class="img recipe-hero-img"
          />
          <article class="recipe-info">
            <h2 class="productname"><?php echo $product['productname'];?></h2>
            <p class="discription">
            <?php echo $product['discription'];?>
            </p>
            <div class="recipe-icons">
              <article>
                <i class="fas fa-clock"></i>
                <h5>prep time</h5>
                <p class="preptime"><?php echo $product['preptime'];?></p>
              </article>
              <article>
                <i class="far fa-clock"></i>
                <h5>cook time</h5>
                <p class="cooktime"><?php echo $product['cooktime'];?></p>
              </article>
              <article>
                <i class="fas fa-user-friends"></i>
                <h5>serving</h5>
                <p class="serving"><?php echo $product['serving'];?></p>
              </article>
            </div>
            <p class="recipe-tags">
              Tags : <a href="tag-template.php">beef</a>
              <a href="tag-template.php">breakfast</a>
              <a href="tag-template.php">pancakes</a>
              <a href="tag-template.php">food</a>
            </p>
          </article>
        </section>
        <!--for icon-->
        
        <!-- content -->
        <section class="recipe-content">
          <article>
            <h4>instructions</h4>
            <!-- single instruction -->
            <div class="single-instruction">
              <header>
                <p>step 1</p>
                <div></div>
              </header>
              <p class="step_1">
              <?php echo $product['instruction1'];?>
              </p>
            </div>
            <!-- end of single instruction -->
            <!-- single instruction -->
            <div class="single-instruction">
              <header>
                <p>step 2</p>
                <div></div>
              </header>
              <p class="step_2">
              <?php echo $product['instruction2'];?>
              </p>
            </div>
            <!-- end of single instruction -->
            <!-- single instruction -->
            <div class="single-instruction">
              <header>
                <p>step 3</p>
                <div></div>
              </header>
              <p class="step_3">
              <?php echo $product['instruction3'];?>
              </p>
            </div>
            <div class="single-instruction">
              <header>
                <p>step 4</p>
                <div></div>
              </header>
              <p class="step_4">
              <?php echo $product['instruction4'];?>
              </p>
            </div>
            <!-- end of single instruction -->
            <div class="single-instruction">
              <header>
                <p>step 5</p>
                <div></div>
              </header>
              <p class="step_5">
              <?php echo $product['instruction5'];?>
              </p>
            </div>
            <!-- end of single instruction -->
            <!-- end of single instruction -->
          </article>
          <article class="second-column">
            <div>
              <h4>ingredients</h4>
              <p class="single-ingredient"><?php echo $product['ingredients'];?></p>
            </div>
            <div>
              <h4>tools</h4>
              <p class="single-tool"><?php echo $product['tools'];?></p>
            </div>
          </article>
        </section>
        <?php }}?>
      </div>
    </main>
    <!-- footer -->
    <footer class="page-footer">
      <p>
        &copy; <span id="date"></span>
        <span class="footer-logo">FOODiez</span> Built by
        <a href="">Pratima Gurung</a>
      </p>
    </footer>
    <script src="./js/app.js"></script>
  </body>
</html>

