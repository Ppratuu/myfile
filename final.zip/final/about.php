<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>About || Final</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="./assets/icon.jpg" type="image/x-icon" />
    <!-- normalize -->
    <link rel="stylesheet" href="./css/normalize.css" />
    <!-- font-awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"
    />
    <!-- main css -->
    <link rel="stylesheet" href="./css/main.css" />
  </head>
  <body>
    <!-- nav  -->
    <nav class="navbar">
      <div class="nav-center">
        <div class="nav-header">
          <a href="index.html" class="nav-logo">
            <img src="./assets/icon.jpg" alt="FOODiez" />
          </a>
          <button class="nav-btn btn">
            <i class="fas fa-align-justify"></i>
          </button>
        </div>
        <div class="nav-links">
          <a href="index.php" class="nav-link"> home </a>
          <a href="about.php" class="nav-link"> about </a>
          <a href="recipes.php" class="nav-link"> recipes </a>
          <a href="index.php?logout=true">LogOut</a>
        </div>
      </div>
    </nav>
    <!-- end of nav -->
    <main class="page">
      <section class="about-page">
        <article>
          <h2>Online Food Recipe System</h2>
          <p>
            This is Capstone-II project that is developed under the topic
            Online Food Recipe System. Here we have simple food recipes.
          </p>
          <p>
            Researching through number of research paper, I am able to create
            up to this level of creation.
          </p>
        </article>
        <!-- needs fixes -->
        <img
          src="./assets/chatpat.jpg"
          alt="Person making chatpatey in Bowl"
          class="img about-img"
        />
      </section>
      <section class="featured-recipes">
        <h5 class="featured-title">Mouthwatering SimplyRecipes!!</h5>
        <div class="recipes-list">
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/haluwa.jpg"
              class="img recipe-img"
              alt=""
            />
            <h5>Haluwa (Suji)</h5>
            <p>Prep : 25min | Cook : 10min</p>
          </a>
          <!-- end of single recipe -->
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/chicken-biryani.jpg"
              class="img recipe-img"
              alt=""
            />
            <h5>Biryani (Chicken)</h5>
            <p>Prep : 45min | Cook : 25min</p>
          </a>
          <!-- end of single recipe -->
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/mushroom soup.jpg"
              class="img recipe-img"
              alt=""
            />
            <h5>Mushroom Soup</h5>
            <p>Prep : 10min | Cook : 7min</p>
          </a>
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/pasta.jpeg"
              class="img recipe-img"
              alt=""
            />
            <h5>Creamy Pasta</h5>
            <p>Prep : 25min | Cook : 15min</p>
          </a>
          <!-- end of single recipe -->
        </div>
      </section>
    </main>
    <!-- footer -->
    <footer class="page-footer">
      <p>
        &copy; <span id="date"></span>
        <span class="footer-logo">FOODiez</span> Built by
        <a href="">Pratima Gurung</a>
      </p>
    </footer>
    <script src="./js/app.js"></script>
  </body>
</html>
