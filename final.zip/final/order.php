<!DOCTYPE html>
<?php include ('connection.php');
if(isset($_GET['id'])){
  $id=$_GET['id'];
}
?>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>FOODiez Order Page</title>
  <link rel="shortcut icon" href="./assets/icon.jpg" type="image/x-icon" />
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"
    />
	<!-- normalize -->
  <link rel="stylesheet" href="./css/normalize.css" />
  <!-- main css -->
  <link rel="stylesheet" href="./css/main.css" />
</head>
<body>
  <!-- nav  -->
<nav class="navbar">
      <div class="nav-center">
        <div class="nav-header">
          <a href="index.php" class="nav-logo">
            <img src="./assets/icon.jpg" alt="FOODiez" />
          </a>
         <!-- <button class="nav-btn btn">
            <i class="fas fa-align-justify"></i>
          </button>-->
        </div>
        
        <div class="nav-links">	
		    <h2>FOODiez</h2>
        </div>
      <div class="nav-links">
          <a href="index.php" class="nav-link"> home </a>
          <a href="about.php" class="nav-link"> about </a>
          <a href="recipes.php" class="nav-link"> recipes </a>
          <a href="index.php?logout=true">LogOut</a>
        </div>
    </div>
</nav>
    <!-- end of nav -->
<div class="container login">
    <div class="d-flex justify-content-center">
        <div class="user_card">
            <div class="d-flex justify-content-center">
                <div class="brand_logo_container">
                    <img src="./assets/icon.jpg" class="brand_logo" alt="FOODiez logo">
                </div>
            </div>
            <div class="d-flex justify-content-center form_container">
                <?php
                $sql="SELECT * FROM `addrecipe` WHERE `id`=$id";
                $res= mysqli_query($db, $sql);
                
                if (mysqli_num_rows($res)>0){ 
                    while ($product=mysqli_fetch_assoc($res)){ 
                ?>
                <form method='post'>
                    <div class="input-group mb-3">
                        Dear user,
                            Your order for <?php echo $product['productname'];?> is on its way. <br>
                            Place place us your location.
                        </h6>
                    </div>
                    <div class="input-group-append">
                        <span class="input-group-text"><i class="fas fa-location"></i></span>
                        <input type="text" name="location" placeholder="Add your location" id="location" class="form-control input_pass" required> <br>
                    </div>  
                    <h6>THANK YOU!!</h6> 
                    <div class="d-flex justify-content-center mt-3 submit_container">
                        <button type="button" class="btn" onclick="openPopup()"> Order Sample</button>
                        <div class="popup" id="popup">
                         
                          <h2>Thank You</h2>
                          <p>Your location has been submitted successfully.</p>
        
                          <button type="button" onclick="closePopup()">OK</button>
                        </div>
                    </div>

                </form>
                <?php }}?>
                <?php 

              if(isset($_POST['submit'])){

                $location 	= $_POST['location'];

                
                $sname = "localhost";
                $uname = "root";
                $password = "";
                $db_name = "final";
                
                $db = mysqli_connect($sname, $uname, $password, $db_name);
                  $sql = "INSERT INTO `location`(`location`) VALUES ('$location')";
                  $stmtinsert = mysqli_query($db, $sql);
              }else{
                echo '';
              }
            ?>
            </div>
        </div>
    </div>

</div>
<script>
      let popup = document.getElementById("popup");

      function openPopup(){
        popup.classList.add("open-popup");
      }
      function closePopup(){
        popup.classList.remove("open-popup");
      }
    </script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<script type="text/javascript">
	$(function(){
		$('#register').click(function(e){

			var valid = this.form.checkValidity();

			if(valid){

			var location 	= $('#location').val();
			

				e.preventDefault();	

				$.ajax({
					type: 'POST',
					url: 'process.php',
					data: { location: location},
					success: function(data){
					Swal.fire({
								'title': 'Successful',
								'text': data,
								'type': 'success'
								})
							
					},
					error: function(data){
						Swal.fire({
								'title': 'Errors',
								'text': 'There were errors while saving the data.',
								'type': 'error'
								})
					}
				});
		
			}else{
				
			}

		});		

		
	});
	
</script>
<br>
<!-- footer -->
<footer class="page-footer">
      <p>
        &copy; <span id="date"></span>
        <span class="footer-logo">FOODiez</span> Built by
        <a href="">Pratima Gurung</a>
      </p>
    </footer>
    <script src="./js/app.js"></script>
</body>
</html>