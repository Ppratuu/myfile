<!DOCTYPE html>
<?php include ('connection.php');
?>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Recipes || Final</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="./assets/icon.jpg" type="image/x-icon" />
    <!-- normalize -->
    <link rel="stylesheet" href="./css/normalize.css" />
    <!-- font-awesome -->
    <link
      rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"
    />
    <!-- main css -->
    <link rel="stylesheet" href="./css/main.css" />
  </head>
  <body>
    <!-- nav  -->
    <nav class="navbar">
      <div class="nav-center">
        <div class="nav-header">
          <a href="index.php" class="nav-logo">
            <img src="./assets/icon.jpg" alt="FOODiez" />
          </a>
          <button class="nav-btn btn">
            <i class="fas fa-align-justify"></i>
          </button>
        </div>
        <div class="nav-links">
          <a href="adminindex.php" class="nav-link"> home </a>
          <a href="adminabout.php" class="nav-link"> about </a>
          <a href="adminrecipe.php" class="nav-link"> recipes </a>
          <a href="users.php" class="nav-link"> users </a>
          <a href="index.php?logout=true">LogOut</a>
          <div class="nav-link contact-link">
            <a href="addrecipe.php">
              <button type="submit" class="btn"> Add Recipe</button>
            </a>
          </div>
        </div>
      </div>
    </nav>
    <!-- end of nav -->
    <!-- main -->
    <main class="page">
      <section class="recipes-container">
        <!-- tag container -->
        
        <!-- end of tag container -->
        <!-- recipes list -->
        <?php
          $sql="SELECT * FROM `addrecipe`Order BY`id`DESC";
          $res= mysqli_query($db, $sql);
          
          if (mysqli_num_rows($res)>0){ 
              while ($product=mysqli_fetch_assoc($res)){ 
        ?>
        <div class=" recipes-list">
          <!-- single recipe -->
          <?php $id= $product['id'];
          ?>
          <a href="<?php echo"single-recipe.php?id=".$id;?>" class="recipe">
            <img
              src="./assets/recipes/<?php echo $product['img'];?>"
              class="img recipe-img"
              alt=""
            />
            <h5><?php echo $product['productname'];?></h5>
            <p>Prep : <?php echo $product['preptime'];?> | Cook : <?php echo $product['cooktime'];?></p>
          </a>
          <!-- end of single recipe -->
        </div>
        <?php }}?>
        
        </div>
      </section>
    </main>
    <!-- end of main -->
    <!-- footer -->
    <footer class="page-footer">
      <p>
        &copy; <span id="date"></span>
        <span class="footer-logo">FOODiez</span> Built by
        <a href="">Pratima Gurung</a>
      </p>
    </footer>
    <script src="./js/app.js"></script>
  </body>
</html>
