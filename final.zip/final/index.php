<?php

  session_start();

  if(isset($_SESSION['userlogin'])){
    header("Location: index.php");
  }
  if(isset($_GET['logout'])){
    session_destroy();
    unset($_SESSION);
    header("Location: login.php");
  }

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>FOODiez || Final</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="./assets/icon.jpg" type="image/x-icon" />
    <!-- normalize -->
    <link rel="stylesheet" href="./css/normalize.css" />
    <!-- font-awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"
    />
    <!-- main css -->
    <link rel="stylesheet" href="./css/main.css" />
  </head>
  <body>
    <!-- nav  -->
    <nav class="navbar">
      <div class="nav-center">
        <div class="nav-header">
          <a href="index.html" class="nav-logo">
            <img src="./assets/icon.jpg" alt="FOODiez" />
          </a>
          <button class="nav-btn btn">
            <i class="fas fa-align-justify"></i>
          </button>
        </div>
        <div class="nav-links">
          <a href="index.php" class="nav-link"> home </a>
          <a href="about.php" class="nav-link"> about </a>
          <a href="recipes.php" class="nav-link"> recipes </a>
          <a href="index.php?logout=true">LogOut</a>
        </div>
      </div>
    </nav>
    <!-- end of nav -->
    <!-- main -->
    <main class="page">
      <!-- header -->
      <header class="hero">
        <div class="hero-container">
          <div class="hero-text">
            <h1>FOODiez</h1>
            <h4>cooking is my therapy</h4>
          </div>
        </div>
      </header>
      <!-- end of header -->
      <section class="recipes-container">
        <!-- recipes list -->
        <div class="recipes-list">
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/haluwa.jpg"
              class="img recipe-img"
              alt=""
            />
            <h5>Haluwa (Suji)</h5>
            <p>Prep : 25min | Cook : 10min</p>
          </a>
          <!-- end of single recipe -->
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/chicken-biryani.jpg"
              class="img recipe-img"
              alt=""
            />
            <h5>Biryani (Chicken)</h5>
            <p>Prep : 45min | Cook : 25min</p>
          </a>
          <!-- end of single recipe -->
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/coffee.jpg"
              class="img recipe-img"
              alt=""
            />
            <h5>Black coffee</h5>
            <p>Prep : 5min | Cook : 3min</p>
          </a>
          <!-- end of single recipe -->
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/pasta.jpeg"
              class="img recipe-img"
              alt=""
            />
            <h5>Creamy Pasta</h5>
            <p>Prep : 25min | Cook : 15min</p>
          </a>
          <!-- end of single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/momo.jpg"
              class="img recipe-img"
              alt=""
            />
            <h5>Chicken Momo</h5>
            <p>Prep : 40min | Cook : 15min</p>
          </a>
          <!-- end of single recipe -->
          <!-- single recipe -->
        </div>
        <!-- end of recipes list -->
      </section>
    </main>
    <!-- end of main -->
    <!-- footer -->
    <footer class="page-footer">
      <p>
        &copy; <span id="date"></span>
        <span class="footer-logo">FOODiez</span> Built by
        <a href="">Pratima Gurung</a>
      </p>
    </footer>
    <script src="./js/app.js"></script>
  </body>
</html>
