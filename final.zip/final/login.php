<?php
  session_start();

  if(isset($_SESSION['userlogin'])){
    header("Location: index.php");
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>FOODiez Login Page</title>
  <link rel="shortcut icon" href="./assets/icon.jpg" type="image/x-icon" />
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<!-- normalize -->
  <link rel="stylesheet" href="./css/normalize.css" />
  <!-- main css -->
  <link rel="stylesheet" href="./css/main.css" />
</head>
<body>
  <!-- nav  -->
<nav class="navbar">
      <div class="nav-center">
        <div class="nav-header">
          <a href="index.html" class="nav-logo">
            <img src="./assets/icon.jpg" alt="FOODiez" />
          </a>
         <!-- <button class="nav-btn btn">
            <i class="fas fa-align-justify"></i>
          </button>-->
        </div>
        <div class="nav-links">	
		    <h2>FOODiez</h2>
          <div class="nav-link contact-link">
            <a href="sign-up.php" class="btn"> Sign Up</a>
          </div>
        </div>
      </div>
</nav>
    <!-- end of nav -->
  <div class="container login">
    <div class="d-flex justify-content-center">
      <div class="user_card">
        <div class="d-flex justify-content-center">
          <div class="brand_logo_container">
            <img src="./assets/icon.jpg" class="brand_logo" alt="FOODiez logo">
          </div>
        </div>
        <div class="d-flex justify-content-center form_container">
          <form action="#" method="post">
            <div class="input-group mb-3">
              <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-user"></i></span>
              </div>
              <input type="text" name="username" id="username" class="form-control input_user" required>
            </div>
            <div class="input-group mb-3">
              <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-key"></i></span>
              </div>
              <input type="password" name="password" id="password" class="form-control input_pass" required>
            </div>
            <div class="form-group">
              <div class="custom-control custom-checkbox">
                <input type="checkbox" name="rememberme" class="custom-control-input" id="customControlInline">
                <label class="custom-control-label" for="customControlInline">Remember me</label>
              </div>
            </div>
          
            </div>
            <div class="d-flex justify-content-center mt-3 login_container">
              <button type="submit" name="button" id="login" class="btn login_btn">Login</button>
            </div>
        </form>
        <?php
        require ("connection.php");
          if (isset($_POST['button'])){
        $username=$_POST['username'];
        $password=$_POST['password'];
         if($username=='admin@admin.com' && $password=='admin'){
           header('location:combine.php');
         }
          else{
            $sql="SELECT `email`, `password` FROM `users` WHERE `email`='$username'  AND `password`='$password'" ;
            $result=mysqli_query($db, $sql);
            $verify= mysqli_num_rows($result);
            if($verify==1){
               header('location:index.php');
            }else{
              echo "Password milena la Pratima";
            }
          }}
        ?>
        <div class="mt-4">
          <div class="d-flex justify-content-center links">
            Don't have an account? <a href="sign-up.php" class="ml-2">Sign Up</a>
          </div>
        </div>
      </div>
    </div>
  </div>
    <script src="http://code.jquery.com/jquery-3.3.1.min.js"
            integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
            crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    
</body>
</html>