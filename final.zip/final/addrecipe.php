<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Addrecipe || Final</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="./assets/icon.jpg" type="image/x-icon" />
    <!-- normalize -->
    <link rel="stylesheet" href="./css/normalize.css" />
    <!-- font-awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"
    />
    <!-- main css -->
    <link rel="stylesheet" href="./css/main.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  </head>
  <body>
    <!-- nav  -->
    <nav class="navbar">
      <div class="nav-center">
        <div class="nav-header">
          <a href="index.html" class="nav-logo">
            <img src="./assets/icon.jpg" alt="FOODiez" />
          </a>
        </div>
        <div class="nav-links">
            <a href="adminindex.php" class="nav-link"> home </a>
            <a href="adminabout.php" class="nav-link"> about </a>
            <a href="combine.php" class="nav-link"> combine </a>
            <a href="users.php" class="nav-link"> users </a>
            <a href="adminrecipe.php" class="nav-link"> recipes </a>
            <a href="index.php?logout=true">LogOut</a>
        </div>
      </div>
    </nav>
    <!-- end of nav -->
    <main class="page">
     <section class="recipe-container">
          <article class="contact-info">
            <h3>Want To Get Add Your Recipe</h3>
            <h5>Let Other to get fan of your Taste!!</h5>
            <p>Dear Users,</p>
            <p>Simply fill up the given form below and add your special <br>
              so that anyone could feel your taste of cuisine.
            </p>
          </article>
          <article>
            <form  class="form recipe-form" method="post">
                  <label for="productname"><b>Product Name</b></label>
                  <input class="form-control" id="productname" type="text" name="productname" > <br>

                  <div class="col-sm-12 form-row">
                      <label for="preptime">Prep Time</label> 
                      <input class="col-sm-3 form-control" id="preptime" type="text" name="preptime" />

                      <label for="cooktime">Cook Time</label>
                      <input class="col-sm-3 form-control" id="cooktime" type="text" name="cooktime" /><br>
                      
                      <label for="serving">Serving</label><br>
                      <select class="col-sm-12 form-select" name="serve" type="text" >
                          <option selected disabled>---Select No of Servings---</option>
                          <option value="1">One</option>
                          <option value="2">Five</option>
                          <option value="3">Ten</option>
                          <option value="4">Fifteen</option>
                      </select>
                      
                      <label for="img">Image</label>
                      <input class="col-sm-12" type="file" name="img" id="img">
                  </div>

                  <div class="form-row">
                      <label for="ingredients">Ingredients</label>
                      <input class="col-sm-12 form-control" type="text" name="ingredients" size="40" id="ingredients" /><br>

                      <label for="tools">Tools</label>
                      <input class="col-sm-12 form-control" type="text" name="tools" size="40" id="tools"/>
                  </div>
                  <div class="form-row">
                        <label class="form-label">Instruction</label>
                        <textarea rows="1" name="instruction1" placeholder="Step-1" id="instruction1" class="form-control"></textarea>
                        <textarea rows="1" name="instruction2" placeholder="Step-2" id="instruction2" class="form-control"></textarea>
                        <textarea rows="1" name="instruction3" placeholder="Step-3" id="instruction3" class="form-control"></textarea>
                        <textarea rows="1" name="instruction4" placeholder="Step-4" id="instruction4" class="form-control"></textarea>
                        <textarea rows="1" name="instruction5" placeholder="Step-5" id="instruction5" class="form-control"></textarea>
                        <label class="form-label">Description</label>
                        <textarea rows="3" name="description" placeholder="Enter small description" id="description" class="form-control" required></textarea>
                  </div>
                  <input type="submit" class="btn btn-info"  name="submit" value="Add Recipe">
            </form>
            <?php 

              if(isset($_POST['submit'])){

                $productname 	= $_POST['productname'];
                $preptime	  	= $_POST['preptime'];
                $cooktime		  = $_POST['cooktime'];
                $serve		    = $_POST['serve'];
                $description	= $_POST['description'];
                $img 			    = $_POST['img'];
                $instruction1	= $_POST['instruction1'];
                $instruction2	= $_POST['instruction2'];
                $instruction3	= $_POST['instruction3'];
                $instruction4	= $_POST['instruction4'];
                $instruction5	= $_POST['instruction5'];
                $ingredients 	= $_POST['ingredients'];
                $tools 		  	= $_POST['tools'];

                
                $sname = "localhost";
                $uname = "root";
                $password = "";
                $db_name = "final";
                
                $db = mysqli_connect($sname, $uname, $password, $db_name);
                  $sql = "INSERT INTO `addrecipe` (`productname`, `preptime`, `cooktime`, `serving`, `discription`, `img`, `instruction1`, `instruction2`, `instruction3`, `instruction4`, `instruction5`, `ingredients`, `tools` ) VALUES('$productname','$preptime','$cooktime','$serve','$description','$img','$instruction1','$instruction2','$instruction3','$instruction4','$instruction5', '$ingredients','$tools')";
                  $stmtinsert = mysqli_query($db, $sql);
              }else{
                echo '';
              }
            ?>
          </article>
        </section>
     <!-- featured recipes -->
       <section class="featured-recipes">
        <h5 class="featured-title">Mouthwatering SimplyRecipes</h5>
        <div class="recipes-list">
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/chicken-biryani.jpg"
              class="img recipe-img"
              alt=""
            />
            <h5>Biryani (Chicken)</h5>
            <p>Prep : 45min | Cook : 25min</p>
          </a>
          <!-- end of single recipe -->
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/mushroom soup.jpg"
              class="img recipe-img"
              alt=""
            />
            <h5>Mushroom Soup</h5>
            <p>Prep : 10min | Cook : 7min</p>
          </a>
          <!-- end of single recipe -->
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/coffee.jpg"
              class="img recipe-img"
              alt=""
            />
            <h5>Black coffee</h5>
            <p>Prep : 5min | Cook : 3min</p>
          </a>
          <!-- end of single recipe -->
          <!-- single recipe -->
        </div>
        </div>
      </section>
    </main>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<script type="text/javascript">
	$(function(){
		$('#register').click(function(e){

			var valid = this.form.checkValidity();

			if(valid){

			var productname 	= $('#productname').val();
			var preptime	    = $('#preptime').val();
			var cooktime 	  	= $('#cooktime').val();
			var serving       = $('#serving').val();
			var description 	= $('#description').val();
      var img           = $('#img').val();
      var instruction  	= $('#instruction1').val();
      var instruction  	= $('#instruction2').val();
      var instruction  	= $('#instruction3').val();
      var instruction  	= $('#instruction4').val();
      var instruction  	= $('#instruction5').val();
      var ingredients 	= $('#ingredients').val();
      var tools       	= $('#tools').val();
			

				e.preventDefault();	

				$.ajax({
					type: 'POST',
					url: 'process.php',
					data: { productname: productname,preptime: preptime,cooktime:cooktime,serving: serving,description: description,img: img,instruction: instruction,ingredients: ingredients,tools: tools},
					success: function(data){
					Swal.fire({
								'title': 'Successful',
								'text': data,
								'type': 'success'
								})
							
					},
					error: function(data){
						Swal.fire({
								'title': 'Errors',
								'text': 'There were errors while saving the data.',
								'type': 'error'
								})
					}
				});
		
			}else{
				
			}

		});		

		
	});
	
</script>
<br>
<br>
    <!-- footer -->
    <footer class="page-footer">
      <p>
        &copy; <span id="date"></span>
        <span class="footer-logo">FOODiez</span> Built by
        <a href="">Pratima Gurung</a>
      </p>
    </footer>
  </body>
</html>
