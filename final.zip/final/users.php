<!DOCTYPE html>
<?php include ('connection.php');
?>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Users || Final</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="./assets/icon.jpg" type="image/x-icon" />
    <!-- normalize -->
    <link rel="stylesheet" href="./css/normalize.css" />
    <!-- font-awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"
    />
    <!-- main css -->
    <link rel="stylesheet" href="./css/main.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  </head>
  <body>
    <!-- nav  -->
    <nav class="navbar">
      <div class="nav-center">
        <div class="nav-header">
          <a href="index.html" class="nav-logo">
            <img src="./assets/icon.jpg" alt="FOODiez" />
          </a>
        </div>
        <div class="nav-links">
            <a href="adminindex.php" class="nav-link"> home </a>
            <a href="adminabout.php" class="nav-link"> about </a>
            <a href="combine.php" class="nav-link"> combine </a>
            <a href="adminrecipe.php" class="nav-link"> recipes </a>
            <a href="index.php?logout=true">LogOut</a>
            <div class="nav-link contact-link">
                <a href="addrecipe.php">
                <button type="submit" class="btn"> Add Recipe</button>
                </a>
            </div>
        </div>
      </div>
    </nav>
    <!-- end of nav -->
    <main class="page">
    <?php
          $sql="SELECT * FROM `users`Order BY`id`DESC";
          $res= mysqli_query($db, $sql);
          
          if (mysqli_num_rows($res)>0){ 
              while ($product=mysqli_fetch_assoc($res)){ 
        ?>
    <table class="table table-secondary">
    <?php $id= $product['id'];
          ?>
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Firstname</th>
            <th scope="col">Lastname</th>
            <th scope="col">Email</th>
            <th scope="col">Phone number</th>
            <th scope="col">password</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row"><?php echo $product['id'];?></th>
                <td><?php echo $product['firstname'];?></td>
                <td><?php echo $product['lastname'];?></td>
                <td><?php echo $product['email'];?></td>
                <td><?php echo $product['phonenumber'];?></td>
                <td><?php echo $product['password'];?></td>
            </tr>
        </tbody>
        <?php }}?>
    </table>
    </main>

    <!-- footer -->
    <footer class="page-footer">
      <p>
        &copy; <span id="date"></span>
        <span class="footer-logo">FOODiez</span> Built by
        <a href="">Pratima Gurung</a>
      </p>
    </footer>
  </body>
</html>
